package EstructuraDatos;

/**
 *
 * @author nova
 */
public class ListaMaterial {

    NodoMaterial cabeza;
    NodoMaterial ultimo;

    public void insertar(String nombreMaterial, int precioCompra, int id) {
        NodoMaterial nuevo = new NodoMaterial(nombreMaterial, precioCompra, id);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(nuevo);
            nuevo.setAnterior(nuevo);

        } else {
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
        }
    }

    public void mostrarAdelante() {
        if (cabeza == null) {
            return;
        }
        NodoMaterial actual = cabeza;
        do {
            System.out.print(actual.getNombreMaterial() + " <-> ");
            actual = actual.getSiguiente();
        } while (actual != cabeza);
        System.out.println("DONE");
    }

    public void insertarOrdenado(String nombreMaterial, int precioCompra, int id) {
        NodoMaterial nuevo = new NodoMaterial(nombreMaterial, precioCompra, id);

        if (cabeza == null) {
            cabeza = nuevo;
            cabeza.setSiguiente(cabeza);
            cabeza.setAnterior(cabeza);

        } else if (cabeza.getId() >= id) {
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
            cabeza = nuevo;

        } else {
            NodoMaterial actual = cabeza;

            while (actual.getSiguiente() != cabeza && actual.getSiguiente().getId() < id) {
                actual = actual.getSiguiente();
            }

            nuevo.setSiguiente(actual.getSiguiente());
            nuevo.setAnterior(actual);
            actual.getSiguiente().setAnterior(nuevo);
            actual.setSiguiente(nuevo);
        }

    }

    public NodoMaterial buscarPorId(int id) {

        if (cabeza == null) {
            return null;
        }

        NodoMaterial actual = cabeza;

        do {
            if (actual.getId() == id) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != cabeza);

        return null;
    }

    // Recorre la lista circular buscando un material por su nombre
    // (se usa para saber el valor del material que se descarta)
    public NodoMaterial buscarPorNombre(String nombreMaterial) {

        if (cabeza == null || nombreMaterial == null) {
            return null;
        }

        NodoMaterial actual = cabeza;

        do {
            if (actual.getNombreMaterial().equalsIgnoreCase(nombreMaterial)) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != cabeza);

        return null;
    }

}
