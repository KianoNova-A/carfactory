package EstructuraDatos;

/**
 *
 * @author nova
 */
public class ListaVehiculo {

    NodoVehiculo cabeza;
    NodoVehiculo ultimo;

    public void insertar(String nombre, int precioVenta, String Material1, String Material2, String Material3, int id) {
        NodoVehiculo nuevo = new NodoVehiculo(nombre, precioVenta, Material1, Material2, Material3, id);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(nuevo);
            nuevo.setAnterior(nuevo);
        } else {
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
        }
    }

    public void mostrarAdelante() {
        if (cabeza == null) {
            return;
        }
        NodoVehiculo actual = cabeza;
        do {
            System.out.print(actual.getNombreVehiculo() + " <-> ");
            actual = actual.getSiguiente();
        } while (actual != cabeza);
        System.out.println("DONE");
    }

    public void insertarOrdenado(String nombre, int precioVenta, String Material1, String Material2, String Material3, int id) {
        NodoVehiculo nuevo = new NodoVehiculo(nombre, precioVenta, Material1, Material2, Material3, id);

        if (cabeza == null) {
            cabeza = nuevo;
            cabeza.setSiguiente(cabeza);
            cabeza.setAnterior(cabeza);
        } else if (cabeza.getId() >= id) {
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
            cabeza = nuevo;
        } else {
            NodoVehiculo actual = cabeza;

            while (actual.getSiguiente() != cabeza && actual.getSiguiente().getId() < id) {
                actual = actual.getSiguiente();
            }

            nuevo.setSiguiente(actual.getSiguiente());
            nuevo.setAnterior(actual);
            actual.getSiguiente().setAnterior(nuevo);
            actual.setSiguiente(nuevo);
        }

    }

    public NodoVehiculo buscarPorId(int id) {

        if (cabeza == null) {
            return null;
        }

        NodoVehiculo actual = cabeza;

        do {
            if (actual.getId() == id) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != cabeza);

        return null;
    }

    // Recorre la lista circular buscando un vehiculo por su nombre
    // (se usa porque cada fabrica muestra solo algunos vehiculos en el JComboBox)
    public NodoVehiculo buscarPorNombre(String nombreVehiculo) {

        if (cabeza == null || nombreVehiculo == null) {
            return null;
        }

        NodoVehiculo actual = cabeza;

        do {
            if (actual.getNombreVehiculo().equalsIgnoreCase(nombreVehiculo)) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != cabeza);

        return null;
    }

}
