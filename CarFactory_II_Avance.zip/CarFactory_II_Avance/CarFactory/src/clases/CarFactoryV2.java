package clases;

/**
 *
 * @author nova
 */
public class CarFactoryV2 {

    public static void main(String[] args) {
       
    }

}
