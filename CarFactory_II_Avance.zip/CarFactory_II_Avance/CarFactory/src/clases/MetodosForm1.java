/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import EstructuraDatos.ListaVehiculo;
import EstructuraDatos.ListaMaterial;
import EstructuraDatos.NodoVehiculo;
import EstructuraDatos.NodoMaterial;

/**
 *
 * @author nova
 */
public class MetodosForm1 {

    private ListaVehiculo vehiculos;
    private ListaMaterial materiales;

    public MetodosForm1() {
        vehiculos = new ListaVehiculo();
        materiales = new ListaMaterial();
    }

    public void registrarVehiculo(String nombre, int precio,
            String material1, String material2,
            String material3, int id) {

        vehiculos.insertarOrdenado(nombre, precio,
                material1, material2, material3, id);
    }

    public void registrarMaterial(String nombre,
            int precio, int id) {

        materiales.insertarOrdenado(nombre, precio, id);
    }

    public String obtenerNombreMaterial(int id) {
        NodoMaterial material = materiales.buscarPorId(id);

        if (material == null) {
            return "Material no encontrado";
        }

        return material.getNombreMaterial();
    }

    public NodoVehiculo obtenerVehiculo(int id) {
        return vehiculos.buscarPorId(id);
    }

    public NodoVehiculo obtenerVehiculoPorNombre(String nombre) {
        return vehiculos.buscarPorNombre(nombre);
    }

    // Vehiculos que puede producir cada fabrica (tabla "Produccion de las fabricas")
    // ids: 0 Sedan de lujo, 1 Pick-up, 2 Maquinaria, 3 Superauto
    public boolean vehiculoPermitido(int numeroFabrica, int idVehiculo) {
        switch (numeroFabrica) {
            case 1:
                return idVehiculo == 0 || idVehiculo == 1;
            case 2:
                return idVehiculo == 0 || idVehiculo == 1 || idVehiculo == 2;
            case 3:
                return idVehiculo == 1 || idVehiculo == 2 || idVehiculo == 3;
            default:
                return false;
        }
    }

    public NodoMaterial obtenerMaterial(int id) {
        return materiales.buscarPorId(id);
    }

    public void mostrarVehiculos() {
        vehiculos.mostrarAdelante();
    }

    public void mostrarMateriales() {
        materiales.mostrarAdelante();
    }

    // ================== CONTADOR DE GANANCIAS ==================
    // Porcentaje del valor del material que se pierde al descartarlo
    private static double PORCENTAJE_PERDIDA = 0.6;

    private double ganancias = 0;

    public double getGanancias() {
        return ganancias;
    }

    public void reiniciarGanancias() {
        ganancias = 0;
    }

    // Suma la ganancia del vehiculo terminado (se busca en la ListaVehiculo)
    public int sumarGananciaVehiculo(int idVehiculo) {
        NodoVehiculo vehiculo = vehiculos.buscarPorId(idVehiculo);

        if (vehiculo == null) {
            return 0;
        }

        ganancias += vehiculo.getPrecioVenta();
        return vehiculo.getPrecioVenta();
    }

    // Resta a las ganancias el 0.6 del valor del material descartado
    // (el valor se busca en la ListaMaterial por nombre)
    public double descontarMaterial(String nombreMaterial) {
        NodoMaterial material = materiales.buscarPorNombre(nombreMaterial);

        if (material == null) {
            return 0;
        }

        double perdida = material.getPrecioCompra() * PORCENTAJE_PERDIDA;
        ganancias -= perdida;
        return perdida;
    }

    // ================== DATOS DE CADA FABRICA ==================
    // Meta de dinero para pasar la fabrica
    public int obtenerMeta(int numeroFabrica) {
        switch (numeroFabrica) {
            case 1:
                return 90000;
            case 2:
                return 125000;
            case 3:
                return 275000;
            default:
                return 0;
        }
    }

    // Puesto del jugador segun la fabrica en la que esta
    public String obtenerPuesto(int numeroFabrica) {
        switch (numeroFabrica) {
            case 1:
                return "Gerente Regional";
            case 2:
                return "Gerente Produccion";
            case 3:
                return "Gerente General";
            default:
                return "";
        }
    }

    public boolean metaAlcanzada(int numeroFabrica) {
        return ganancias >= obtenerMeta(numeroFabrica);
    }

}
