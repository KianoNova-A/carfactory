package Logica;

public class ColaMateriales {

    private NodoMaterial frente;
    private NodoMaterial fin;

    public ColaMateriales() {
        frente = null;
        fin = null;
    }

    public void encolar(String material) {

        NodoMaterial nuevo = new NodoMaterial(material);

        if (fin == null) {
            frente = nuevo;
            fin = nuevo;
            return;
        }

        fin.siguiente = nuevo;
        fin = nuevo;
    }

    public String desencolar() {

        if (frente == null) {
            return null;
        }

        String material = frente.material;

        frente = frente.siguiente;

        if (frente == null) {
            fin = null;
        }

        return material;
    }
}