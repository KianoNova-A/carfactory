package Logica;

public class Materiales {

    private static final ColaMateriales cola = new ColaMateriales();

    static {

        cola.encolar("Motor de lujo");
        cola.encolar("Motor especial deportivo");
        cola.encolar("Carrocería");
        cola.encolar("Carrocería especial");
        cola.encolar("Llantas deportivas");
        cola.encolar("Llantas únicas de trabajo");

    }

    public static String materialAleatorio() {

        String material = cola.desencolar();

        cola.encolar(material);

        return material;
    }

    public static String obtenerMaterial(int numero) {

        return switch (numero) {
            case 0 -> "Motor de lujo";
            case 1 -> "Motor especial deportivo";
            case 2 -> "Carrocería";
            case 3 -> "Carrocería especial";
            case 4 -> "Llantas deportivas";
            case 5 -> "Llantas únicas de trabajo";
            default -> "Error";
        };
    }
}