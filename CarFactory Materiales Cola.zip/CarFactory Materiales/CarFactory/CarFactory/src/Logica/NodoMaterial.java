package Logica;

public class NodoMaterial {

    String material;
    NodoMaterial siguiente;

    public NodoMaterial(String material) {
        this.material = material;
        this.siguiente = null;
    }
}