package logica;

public class Materiales {

    public static String obtenerMaterial(int numero) {

        switch (numero) {
            case 0:
                return "Motor de lujo";
            case 1:
                return "Motor especial deportivo";
            case 2:
                return "Carrocería";
            case 3:
                return "Carrocería especial";
            case 4:
                return "Llantas deportivas";
            case 5:
                return "Llantas únicas de trabajo";
            default:
                return "Error";
        }
    }

    public static String materialAleatorio() {

        int n = (int)(Math.random() * 6);

        return obtenerMaterial(n);
    }
}