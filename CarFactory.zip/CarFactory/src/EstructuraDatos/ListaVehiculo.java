package EstructuraDatos;

/**
 *
 * @author nova
 */
public class ListaVehiculo {
    NodoVehiculo cabeza;
    NodoVehiculo ultimo;
    
    public void insertar(String nombre, int precioVenta, String Material1, String Material2, String Material3, int id){
        NodoVehiculo nuevo = new NodoVehiculo(nombre, precioVenta, Material1, Material2, Material3, id);
        if(cabeza == null){
            cabeza = nuevo;
        } else {
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
        }
    }
    
    public void mostrarAdelante(){
        if(cabeza ==  null){
            return;
        }
        NodoVehiculo actual = cabeza;
        do{
            System.out.print(actual.getNombreVehiculo() + " <-> ");
            actual = actual.getSiguiente();
        } while(actual != cabeza);
        System.out.println("DONE");
    }
    
    public void insertarOrdenado(String nombre, int precioVenta, String Material1, String Material2, String Material3, int id){
        NodoVehiculo nuevo = new NodoVehiculo(nombre, precioVenta, Material1, Material2, Material3, id);
        
        if(cabeza == null){
            cabeza = nuevo;
            cabeza.setSiguiente(cabeza);
            cabeza.setAnterior(cabeza);
        } else if(cabeza.getId() >= id){
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
            cabeza = nuevo;
        } else {
            NodoVehiculo actual = cabeza;
            
            while(actual.getSiguiente() != cabeza && actual.getSiguiente().getId() < 10){
                actual = actual.getSiguiente();
            }
            
            nuevo.setSiguiente(actual.getSiguiente());
            nuevo.setAnterior(actual);
            actual.getSiguiente().setAnterior(nuevo);
            actual.setSiguiente(nuevo);
        }
        
    }
    
        
}



