package EstructuraDatos;

/**
 *
 * @author nova
 */
public class NodoVehiculo {
    private String nombreVehiculo;
    private int precioVenta;
    private String Material1;
    private String Material2;
    private String Material3;
    
    private int id;
    private NodoVehiculo siguiente;
    private NodoVehiculo anterior;
    
    public NodoVehiculo(String nombreVehiculo, int precioVenta, String Material1, String Material2, String Material3, int id){
        this.nombreVehiculo = nombreVehiculo;
        this.precioVenta = precioVenta;
        this.Material1 = Material1;
        this.Material2 = Material2;
        this.Material3 = Material3;
        this.id = id;
        this.siguiente = null;
        this.anterior = null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public NodoVehiculo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoVehiculo siguiente) {
        this.siguiente = siguiente;
    }

    public NodoVehiculo getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoVehiculo anterior) {
        this.anterior = anterior;
    }

    public String getNombreVehiculo() {
        return nombreVehiculo;
    }

    public void setNombreVehiculo(String nombreVehiculo) {
        this.nombreVehiculo = nombreVehiculo;
    }

    public int getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(int precioVenta) {
        this.precioVenta = precioVenta;
    }

    public String getMaterial1() {
        return Material1;
    }

    public void setMaterial1(String Material1) {
        this.Material1 = Material1;
    }

    public String getMaterial2() {
        return Material2;
    }

    public void setMaterial2(String Material2) {
        this.Material2 = Material2;
    }

    public String getMaterial3() {
        return Material3;
    }

    public void setMaterial3(String Material3) {
        this.Material3 = Material3;
    }

    
    
    
}
