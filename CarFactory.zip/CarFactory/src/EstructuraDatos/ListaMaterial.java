package EstructuraDatos;
/**
 *
 * @author nova
 */
public class ListaMaterial {
    NodoMaterial cabeza;
    NodoMaterial ultimo;
    
    public void insertar(String nombreMaterial, int precioCompra, int id){
        NodoMaterial nuevo = new NodoMaterial(nombreMaterial, precioCompra, id);
        if(cabeza == null){
            cabeza = nuevo;
        } else {
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
        }
    }
    
    public void mostrarAdelante(){
        if(cabeza ==  null){
            return;
        }
        NodoMaterial actual = cabeza;
        do{
            System.out.print(actual.getNombreMaterial() + " <-> ");
            actual = actual.getSiguiente();
        } while(actual != cabeza);
        System.out.println("DONE");
    }
    
    public void insertarOrdenado(String nombreMaterial, int precioCompra, int id){
        NodoMaterial nuevo = new NodoMaterial(nombreMaterial, precioCompra, id);
        
        if(cabeza == null){
            cabeza = nuevo;
            cabeza.setSiguiente(cabeza);
            cabeza.setAnterior(cabeza);
        } else if(cabeza.getId() >= id){
            ultimo = cabeza.getAnterior();
            nuevo.setSiguiente(cabeza);
            nuevo.setAnterior(ultimo);
            cabeza.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
            cabeza = nuevo;
        } else {
            NodoMaterial actual = cabeza;
            
            while(actual.getSiguiente() != cabeza && actual.getSiguiente().getId() < 10){
                actual = actual.getSiguiente();
            }
            
            nuevo.setSiguiente(actual.getSiguiente());
            nuevo.setAnterior(actual);
            actual.getSiguiente().setAnterior(nuevo);
            actual.setSiguiente(nuevo);
        }
        
    }
        
   
        
}


