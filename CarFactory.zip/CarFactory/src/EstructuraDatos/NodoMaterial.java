package EstructuraDatos;
/**
 *
 * @author nova
 */
public class NodoMaterial {
    private String nombreMaterial;
    private int precioCompra;
    
    private int id;
    private NodoMaterial siguiente;
    private NodoMaterial anterior;
    
    public NodoMaterial(String nombreMaterial, int precioCompra, int id){
        this.nombreMaterial = nombreMaterial;
        this.precioCompra = precioCompra;
        this.id = id;
        this.siguiente = null;
        this.anterior = null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreMaterial() {
        return nombreMaterial;
    }

    public void setNombreMaterial(String nombreMaterial) {
        this.nombreMaterial = nombreMaterial;
    }

    public int getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(int precioCompra) {
        this.precioCompra = precioCompra;
    }

    public NodoMaterial getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoMaterial siguiente) {
        this.siguiente = siguiente;
    }

    public NodoMaterial getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoMaterial anterior) {
        this.anterior = anterior;
    }

    
   
}
