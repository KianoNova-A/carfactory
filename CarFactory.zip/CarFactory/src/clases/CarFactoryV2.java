package clases;

import EstructuraDatos.ListaMaterial;
import EstructuraDatos.ListaVehiculo;
/**
 *
 * @author nova
 */
public class CarFactoryV2 {
    public static void main(String[] args) {
        ListaVehiculo lv =  new ListaVehiculo();
        
        lv.insertarOrdenado("Sedan de lujo", 5000, "Motor de lujo", "Carroceria", null, 0);
        lv.insertarOrdenado("Pick-up de alta gama", 12000, "Motor de lujo", "Carroceria", null, 1);
        lv.insertarOrdenado("Maquinaria de alta gama para trabajos pesados", 17500, "Motor espeial deportivo", "Carroceria especial", "Llantas unicas de trabajo", 2);
        lv.insertarOrdenado("Superauto Deportivo", 20000, "Motor espeial deportivo", "Carroceria", "Llantas deportivas", 3);
        
        lv.mostrarAdelante();
        
        ListaMaterial lm = new ListaMaterial();
        
        lm.insertarOrdenado("Motor de lujo", 500, 0);
        lm.insertarOrdenado("Motor especial deportivo", 2000, 1);
        lm.insertarOrdenado("Carroceria", 500, 2);
        lm.insertarOrdenado("Carroceria especial", 800, 3);
        lm.insertarOrdenado("Llantas deportivas", 2000, 4);
        lm.insertarOrdenado("Llantas unicas de de trabajo", 800, 5);
        
        lm.mostrarAdelante();
        
        
    }
    
}
