/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import EstructuraDatos.ListaVehiculo;
import EstructuraDatos.ListaMaterial;
import EstructuraDatos.NodoVehiculo;
import EstructuraDatos.NodoMaterial;

/**
 *
 * @author nova
 */
public class MetodosForm1 {

    private ListaVehiculo vehiculos;
    private ListaMaterial materiales;

    public MetodosForm1() {
        vehiculos = new ListaVehiculo();
        materiales = new ListaMaterial();
    }

    public void registrarVehiculo(String nombre, int precio,
            String material1, String material2,
            String material3, int id) {

        vehiculos.insertarOrdenado(nombre, precio,
                material1, material2, material3, id);
    }

    public void registrarMaterial(String nombre,
            int precio, int id) {

        materiales.insertarOrdenado(nombre, precio, id);
    }

    public String obtenerNombreMaterial(int id) {
        NodoMaterial material = materiales.buscarPorId(id);

        if (material == null) {
            return "Material no encontrado";
        }

        return material.getNombreMaterial();
    }

    public NodoVehiculo obtenerVehiculo(int id) {
        return vehiculos.buscarPorId(id);
    }

    public NodoMaterial obtenerMaterial(int id) {
        return materiales.buscarPorId(id);
    }

    public void mostrarVehiculos() {
        vehiculos.mostrarAdelante();
    }

    public void mostrarMateriales() {
        materiales.mostrarAdelante();
    }

}
