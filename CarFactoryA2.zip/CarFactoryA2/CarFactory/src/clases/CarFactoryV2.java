package clases;

import formularios.Fabrica_1;
import javax.swing.SwingUtilities;

/**
 *
 * @author nova
 */
public class CarFactoryV2 {

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(() -> {
            new Fabrica_1().setVisible(true);
        });
        
    }

}
