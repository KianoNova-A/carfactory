/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author abelm
 */
public class Vehiculo {
    private String nombre;
    private double precioVenta;
    private double costoFabrica;
    private int numeroFabrica;

    public Vehiculo(String nombre, double precioVenta, double costoFabrica, int fabricacion) {
        this.nombre = nombre;
        this.precioVenta = precioVenta;
        this.costoFabrica = costoFabrica;
        this.numeroFabrica = numeroFabrica;
    }

    public int getFabricacion() {
        return numeroFabrica;
    }

    public void setFabricacion(int fabricacion) {
        this.numeroFabrica = fabricacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(double precioVenta) {
        this.precioVenta = precioVenta;
    }

    public double getCostoFabrica() {
        return costoFabrica;
    }

    public void setCostoFabrica(double costoFabrica) {
        this.costoFabrica = costoFabrica;
    }
    
    
}
