/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebas;

import modelo.Vehiculo;
import servicios.GestorVehiculo;

/**
 *
 * @author abelm
 */
public class PruebaGestorVehiculo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        GestorVehiculo gestor = new GestorVehiculo();

        Vehiculo sedan = new Vehiculo("Sedan de lujo", 5000, 1000, 1);

        gestor.registrarVehiculo(sedan);

        gestor.mostrarVehiculos();

        Vehiculo encontrado = gestor.buscarVehiculo("Sedan de lujo");

        if (encontrado != null) {
            System.out.println("Vehiculo encontrado: " + encontrado.getNombre()
                    + "\n Precio de venta: " + encontrado.getPrecioVenta()
                    + "\n Costo de fabricacion: " + encontrado.getCostoFabrica());
            double ganancia = encontrado.getPrecioVenta() - encontrado.getCostoFabrica();
            System.out.println("Ganancia bruta: " + ganancia);
        } else {
            System.out.println("Vehiculo no encontrado.");
        }
    }

}
