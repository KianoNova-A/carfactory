/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebas;
import estructura.ListaVehiculos;
import modelo.Vehiculo;
/**
 *
 * @author abelm
 */
public class PruebaListaVehiculos {
    public static void main(String[] args){
        
        ListaVehiculos lista = new ListaVehiculos();
        
        // Creacion de Vehiculos
        Vehiculo vehiculo1 = new Vehiculo("Sedan de lujo", 5000, 1000, 1);
        Vehiculo vehiculo2 = new Vehiculo("Pick-up de alta gama", 12000, 1000, 2);
        
        // Insertar vehiculos
        lista.insertarFinal(vehiculo1);
        lista.insertarFinal(vehiculo2);
        
        System.out.println("Recorrido normal:");
        lista.mostrarVehiculos();
        
        System.out.println("Recorrido inverso:");
        lista.mostrarVehiculoInverso();
        
        
    }
}
