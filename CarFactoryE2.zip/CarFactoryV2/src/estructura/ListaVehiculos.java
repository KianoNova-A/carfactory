package estructura;

import modelo.Vehiculo;

/**
 *
 * @author abelm
 */
public class ListaVehiculos {

    private NodoVehiculo cabeza;

    public ListaVehiculos() {
        this.cabeza = null;
    }

    public boolean estaVacia() {
        return cabeza == null;
    }

    public void insertarFinal(Vehiculo vehiculo) {
        NodoVehiculo nuevo = new NodoVehiculo(vehiculo);

        if (estaVacia()) {
            cabeza = nuevo;
        } else {
            NodoVehiculo actual = cabeza;

            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
            nuevo.setAnterior(actual);
        }
    }

    public void mostrarVehiculos() {
        NodoVehiculo actual = cabeza;

        while (actual != null) {
            System.out.println(actual.getDato().getNombre());
            actual = actual.getSiguiente();
        }
    }

    public void mostrarVehiculoInverso() {
        if (estaVacia()) {
            return;
        }

        NodoVehiculo actual = cabeza;

        while (actual.getSiguiente() != null) {
            actual = actual.getSiguiente();
        }

        while (actual != null) {
            System.out.println(actual.getDato().getNombre());
            actual = actual.getAnterior();
        }
    }

    public Vehiculo buscarPorNombre(String nombre) {

        NodoVehiculo actual = cabeza;

        while (actual != null) {
            
            if (actual.getDato().getNombre().equals(nombre)) {
                return actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }
}
