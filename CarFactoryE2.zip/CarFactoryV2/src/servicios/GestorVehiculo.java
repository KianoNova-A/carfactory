package servicios;

import estructura.ListaVehiculos;
import modelo.Vehiculo;

/**
 *
 * @author abelm
 */
public class GestorVehiculo {

    private ListaVehiculos lista;

    public GestorVehiculo() {
        this.lista = new ListaVehiculos();
    }

    public void registrarVehiculo(Vehiculo vehiculo) {
        lista.insertarFinal(vehiculo);
    }
    
    public void mostrarVehiculos() {
        lista.mostrarVehiculos();
    }
    
    public Vehiculo buscarVehiculo(String nombre) {
        return lista.buscarPorNombre(nombre);
    }
    
    public double calcularGanancia(Vehiculo vehiculo){
        return vehiculo.getPrecioVenta() - vehiculo.getCostoFabrica();
    }

}
